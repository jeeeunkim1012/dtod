import React, { useState, useEffect } from 'react';
import AdminNotice from '../../components/AdminNoticeItem';
import Container from 'react-bootstrap/Container';
import Row from 'react-bootstrap/Row';
import Col from 'react-bootstrap/Col';
import '../css/anList.css';
import '../css/reset.css';
import { Link } from 'react-router-dom/cjs/react-router-dom.min';

const ANList = () => {

  const [aNotice, setANotice] = useState([]);

  // useEffect: 함수 실행시 최초 한번 실행되는 것 + 상태값이 변경될때마다 실행
  useEffect(()=>{
    fetch("http://localhost:9005/adminNotice").then(res => res.json()).then(res => {
      console.log(1,res);
      setANotice(res);
    }); // 비동기 함수, fetch를 이용해서 서버에 이 데이터 달라고 요청하는 것.(axios 사용x)
  }, []) // 만약 배열([])이 없다면 목록이 생길 때 무한루프를 돌게 된다. 
         // [] 은 '나는 어디에도 의존하고 있지 않아'라는 의미이다.

    return (
      <div className='wrap'>
        <Container className='mt150'>
          <Row className='mb80'>
            <Col md={4} className='antitle'>공지사항</Col>
          </Row>
          <Row className='antop btnPurple fontPurple mb10'>
              <Col xs={1} className='anTextLeft '>번호</Col>
              <Col xs={7} className='anTextCenter'>제목</Col>
              <Col className='anTextLeft anTextWriter'>작성자</Col>
              <Col className='anTextLeft'>등록일</Col>
          </Row>
          {aNotice.map((aNotice) => (
            <AdminNotice key={aNotice.nobno} aNotice={aNotice}/>
          ))}
          <Row xs="auto">
            <Col md={{ span: 11, offset: 11 }} className='mt20'><Link to="/anSaveForm" className='anwrite'>글쓰기</Link></Col>
          </Row>
        </Container>
      </div>
    );
};

export default ANList;