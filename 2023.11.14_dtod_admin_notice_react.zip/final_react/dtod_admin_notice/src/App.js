import { Route } from 'react-router-dom/cjs/react-router-dom.min';
import './App.css';
import Container from 'react-bootstrap/Container';
import Header from './components/Header';
import ANSaveForm from './pages/board/ANSaveForm';
import ANList from './pages/board/ANList';
import ANUpdateForm from './pages/board/ANUpdateForm';
import ANDetail from './pages/board/ANDetail';
import JoinForm from './pages/user/JoinForm';
import LoginForm from './pages/user/LoginForm';

function App() {
  return (
    <div>
      <Header />
      <Container>
        <Route path="/" exact={true} component={ANList} /> {/* 목록보기 */}
        <Route path="/anSaveForm" exact={true} component={ANSaveForm} /> {/* 글쓰기(등록하기) */}
        <Route path="/adminNotice/:nobno" exact={true} component={ANDetail} /> {/* 한 건만 보는 상세 페이지 */}
        <Route path="/loginForm" exact={true} component={LoginForm} /> {/* 로그인 */}
        <Route path="/joinForm" exact={true} component={JoinForm} /> {/* 가입 */}
        <Route path="/updateForm/:nobno" exact={true} component={ANUpdateForm} /> {/* 책 수정 */}
      </Container>
    </div>
  );
}

export default App;