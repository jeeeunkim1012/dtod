# React-Springboot admin notice board 

## 스프링부트
- springboot ^2.0
- JPA
- Oracle DB
- Maven
- Lombok

## REACT
### router-dom
- npm install -save react-router-dom@5.3.0
- npm install redux react-redux

### react bootstrap
- npm install react-bootstrap bootstrap

### bootstrap
- npm install -save bootstrap@4.4.1

### axios
- npm install axios

### fontawesom
- npm i @fortawesome/fontawesome-svg-core
- npm i @fortawesome/free-solid-svg-icons @fortawesome/free-regular-svg-icons @fortawesome/free-brands-svg-icons
- npm i @fortawesome/react-fontawesome

### aos
- npm install aos --save

### slick
- npm install react-slick --save

### carousel
- npm install slick-carousel

### swiper
- npm install swiper

```json
{
    "singleQuote":true,
    "semi":true,
    "tabWidth":2,
    "trailingComma":"all",
    "printWidth":80
}

```txt
import 'bootstrap/dist/css/bootstrap.min.css';
```